# No custom rules needed for debug-focused app.


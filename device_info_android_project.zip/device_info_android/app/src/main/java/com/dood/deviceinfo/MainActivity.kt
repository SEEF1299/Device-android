package com.dood.deviceinfo

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.text.format.Formatter
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var tvHeader: TextView
    private lateinit var tvCpu: TextView
    private lateinit var tvRam: TextView
    private lateinit var tvStorage: TextView
    private lateinit var tvBattery: TextView
    private lateinit var tvBuild: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val updater = object : Runnable {
        override fun run() {
            renderInfo()
            handler.postDelayed(this, 2000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvHeader = findViewById(R.id.tvHeader)
        tvCpu = findViewById(R.id.tvCpu)
        tvRam = findViewById(R.id.tvRam)
        tvStorage = findViewById(R.id.tvStorage)
        tvBattery = findViewById(R.id.tvBattery)
        tvBuild = findViewById(R.id.tvBuild)

        renderInfo()
    }

    override fun onResume() {
        super.onResume()
        handler.post(updater)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(updater)
    }

    private fun renderInfo() {
        tvHeader.text = "Device Info Dashboard"

        val cores = Runtime.getRuntime().availableProcessors()
        val load = readLoadAvg()
        tvCpu.text = "CPU Cores: $cores\nLoad Avg: $load"

        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val total = Formatter.formatFileSize(this, memInfo.totalMem)
        val avail = Formatter.formatFileSize(this, memInfo.availMem)
        val usedPct = ((memInfo.totalMem - memInfo.availMem).toDouble() / memInfo.totalMem * 100.0)
        tvRam.text = "RAM: %.1f%% used\nTotal: %s\nAvailable: %s".format(usedPct, total, avail)

        val dataDir = Environment.getDataDirectory()
        val statFs = StatFs(dataDir.path)
        val totalBytes = statFs.totalBytes
        val availableBytes = statFs.availableBytes
        val usedBytes = totalBytes - availableBytes
        val storagePct = (usedBytes.toDouble() / totalBytes.toDouble()) * 100.0
        tvStorage.text =
            "Storage: %.1f%% used\nUsed: %s\nFree: %s".format(
                storagePct,
                Formatter.formatFileSize(this, usedBytes),
                Formatter.formatFileSize(this, availableBytes)
            )

        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val batt = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val plugged = bm.isCharging
        tvBattery.text = "Battery: $batt%\nCharging: ${if (plugged) "Yes" else "No"}"

        tvBuild.text =
            "Brand: ${Build.BRAND}\nModel: ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})"
    }

    private fun readLoadAvg(): String {
        return try {
            val line = File("/proc/loadavg").readText().trim()
            line.split(" ").take(3).joinToString(", ")
        } catch (_: Exception) {
            "N/A"
        }
    }
}

